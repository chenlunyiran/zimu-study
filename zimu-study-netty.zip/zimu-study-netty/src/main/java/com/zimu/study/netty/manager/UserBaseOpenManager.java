package com.zimu.study.netty.manager;

import com.alibaba.dubbo.config.annotation.Reference;
import com.fota.account.service.UserBaseService;
import com.fota.idgenerator.service.IdGenerator;
import com.fota.open.option.SdkSession;
import com.fota.open.option.annotation.ws.WSMessageDispatcher;
import com.fota.open.option.domain.UserBaseDO;
import com.fota.open.option.domain.UserWalletDO;
import com.fota.open.option.domain.vo.OpenCapitalAssetsVO;
import com.fota.open.option.mapper.OptionUserBaseMapper;
import com.fota.open.option.mapper.OptionUserWalletMapper;
import com.fota.open.option.service.UserChannelBinder;
import com.fota.open.option.util.RandomStringUtil;
import com.fota.option.common.constants.RedisKeyConstants;
import com.fota.option.enums.OptionRoleEnum;
import com.fota.option.manager.RedisManager;
import com.fota.option.service.OptionService;
import com.zimu.study.netty.constants.RedisKeyConstants;
import com.zimu.study.netty.model.SdkSession;
import io.netty.channel.Channel;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import javax.annotation.Resource;
import java.math.BigDecimal;
import java.time.Duration;
import java.util.Arrays;
import java.util.List;
import java.util.Optional;

import static com.fota.option.common.constants.RedisKeyConstants.getTokenKey;

/**
 * @author Gavin Shen
 * @Date 2019/1/15
 */
@Component
@Slf4j
public class UserBaseOpenManager {

    @Resource
    private OptionUserBaseMapper optionUserBaseMapper;
    @Resource
    private OptionUserWalletMapper optionUserWalletMapper;
    @Resource
    private RedisManager redisManager;
    @Resource
    private IdGenerator userIdGenerator;
    @Autowired
    private WSMessageDispatcher wsMessageDispatcher;
    @Autowired
    private UserChannelBinder userChannelBinder;
    @Autowired
    private BrokerConfigManager brokerConfigManager;
    @Reference
    private UserBaseService userBaseService;
    @Autowired
    private UserOpenCacheManager userOpenCacheManager;
    @Autowired
    private OptionService optionService;
    /**
     * 创建账户，默认新加BTC和ETH的币种钱包信息
     * @param userBaseDO
     * @return
     */
    public Long addUser(UserBaseDO userBaseDO) {
        try {
            Long userId = userIdGenerator.nextId();
            userBaseDO.setUserId(userId);
            userBaseDO.setValid(0);
            int insertRet = optionUserBaseMapper.insert(userBaseDO);
            if (insertRet > 0) {
                Optional<List<OpenCapitalAssetsVO>> capitalAssetsVOS = Optional.ofNullable(brokerConfigManager.getCapitalAssetsByBrokerId(userBaseDO.getBrokerId()));
                if (capitalAssetsVOS.isPresent()) {
                    capitalAssetsVOS.get().forEach(openCapitalAssetsVO -> {
                        OptionRoleEnum optionRoleEnum = OptionRoleEnum.getOptionRoleEnumByCode(openCapitalAssetsVO.getId());
                        if (optionRoleEnum != null) {
                            initUserWallet(userBaseDO, OptionRoleEnum.getOptionRoleEnumByCode(openCapitalAssetsVO.getId()));
                        } else {
                            log.error("OptionRoleEnum.getOptionRoleEnumByCode error, code:{}", openCapitalAssetsVO.getId());
                        }
                    });
                }
                return userId;
            }
        } catch (Exception e) {
            log.error("userBaseMapper.insert({}) exception", userBaseDO, e);
        }
        return null;
    }

    /**
     * 更新用户昵称
     * @param brokerId
     * @param userId
     * @param userName
     * @return
     */
    public boolean updateUserName(Long brokerId, Long userId, String userName) {
        // 券商
        try {
            Integer count = optionUserBaseMapper.updateUserName(userId, userName);
            if (count > 0) {
                // 修改排行榜的用户昵称
                optionService.updateRankUsername(userId, userName, brokerId);
                return true;
            }
        } catch (Exception e) {
            log.error("userBaseManager.updateUserName error. brokerId:{}, userId:{}, userName:{}", brokerId, userId, userName);
        }
        return false;
    }

    /**
     * 根据券商用户的suid和券商id获取用户注册信息
     * @param suid
     * @param brokerId
     * @return
     */
    public UserBaseDO getBySuidBrokerId(String suid, Long brokerId) {
        try {
            UserBaseDO userBaseDO = optionUserBaseMapper.getBySuidBrokerId(suid, brokerId);
            return userBaseDO;
        } catch (Exception e) {
            log.error("optionUserBaseMapper.getBySuidBrokerId({}, {}) exception", suid, brokerId, e);
        }
        return null;
    }

    public UserWalletDO initUserWallet(UserBaseDO userBaseDO, OptionRoleEnum optionRoleEnum) {
        UserWalletDO userWalletDO = new UserWalletDO();
        userWalletDO.setUserId(userBaseDO.getUserId());
        userWalletDO.setBrokerId(userBaseDO.getBrokerId());
        userWalletDO.setAssetId(optionRoleEnum.getId());
        userWalletDO.setAssetName(optionRoleEnum.getName());
        if (optionRoleEnum.getId() == OptionRoleEnum.VFOTA.getId()) {
            userWalletDO.setAmount(new BigDecimal("10000"));
        } else {
            userWalletDO.setAmount(BigDecimal.ZERO);
        }
        optionUserWalletMapper.insert(userWalletDO);
        return userWalletDO;
    }

    public UserBaseDO getUserBaseInfo(Long userId) {
        return optionUserBaseMapper.getByUserId(userId);
    }


    public String login(Long userId, String password, Long tokenFailureTime, Long brokerId) {
        // token默认七天失效
        if (tokenFailureTime == null || tokenFailureTime == 0) {
            tokenFailureTime = 3600 * 24 * 7L;
        }
        try {
            UserBaseDO userBaseDO = optionUserBaseMapper.getByUserId(userId);
            if (!password.equals(userBaseDO.getPassword())) {
                return null;
            }
            String token = RandomStringUtil.getRandomString(10);
            boolean saveRet = redisManager.setWithExpire(getTokenKey(userId), getTokenAndBrokerId(token, brokerId), Duration.ofSeconds(tokenFailureTime));
            return saveRet ? token : null;
        } catch (Exception e) {
            log.error("login exception", e);
        }
        return null;
    }

    public boolean logout(Long userId) {
        redisManager.del(getTokenKey(userId));
        for (Channel channel : UserChannelBinder.getChannelByUser(userId.toString())) {
            wsMessageDispatcher.removeChannel(channel, userId.toString());
            wsMessageDispatcher.unbindChannel(channel, userId.toString());
        }
        return true;
    }

    /**
     * 用户是否存在
     * @param userId
     * @return
     */
    public Boolean isExist(Long userId) {
        UserBaseDO userBaseDO = optionUserBaseMapper.getByUserId(userId);
        if (userBaseDO == null) {
            return false;
        }
        return true;
    }

    public String getTokenByUserId(Long userId) {
        try {
            String tokenAndBrokerId = (String) redisManager.get(String.valueOf(getTokenKey(userId)));
            if (StringUtils.isEmpty(tokenAndBrokerId)) {
                return null;
            }
            List<String> list = Arrays.asList(tokenAndBrokerId.split("_fota_"));
            if (list != null && list.size() >= 1) {
                return list.get(0);
            }
        } catch (Exception e) {
            log.error("getToken({}) error!", userId, e);
        }
        return null;
    }
    public String getBrokerIdByUserId(Long userId) {
        try {
            String tokenAndBrokerId = (String) redisManager.get(String.valueOf(getTokenKey(userId)));
            if (StringUtils.isEmpty(tokenAndBrokerId)) {
                return null;
            }
            List<String> list = Arrays.asList(tokenAndBrokerId.split("_fota_"));
            if (list != null && list.size() >= 2) {
                return list.get(1);
            }
        } catch (Exception e) {
            log.error("getBrokerId({}) error!", userId, e);
        }
        return null;
    }

    public SdkSession getSessionByUserId(String uId){
        if (StringUtils.isEmpty(uId)) {
            log.error("empty userId when getSessionByUserId");
            return new SdkSession();
        }
        try {
            String tokenAndBrokerId = (String) redisManager.get(String.valueOf(RedisKeyConstants.getTokenKey(Long.parseLong(uId))));
            if (StringUtils.isEmpty(tokenAndBrokerId)) {
                return new SdkSession();
            }
            String [] list = tokenAndBrokerId.split("_fota_");
            if (list != null && list.length > 1) {
                return new SdkSession( Long.parseLong(list[1]), list[0]);
            }
        }catch (Exception e) {
            log.error("get getSessionByUserId({}) exception", uId, e);
        }
        return new SdkSession();
    }

    private String getTokenAndBrokerId(String token, Long brokerId) {
        return token + "_fota_" + brokerId;
    }

}
