package com.zimu.study.netty.annotation.ws;

import com.zimu.study.netty.constants.WSOps;
import org.springframework.core.annotation.AliasFor;

import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;

/**
 * @author xue
 * Created on 2019-02-14.
 */
@Target({ElementType.TYPE, ElementType.METHOD})
@Retention(RetentionPolicy.RUNTIME)
@WsOpMapping(op = WSOps.SUBSCRIBE)
public @interface WsSubscribeOpMapping {

    @AliasFor(annotation = WsOpMapping.class, attribute = "url")
    String value();
}
