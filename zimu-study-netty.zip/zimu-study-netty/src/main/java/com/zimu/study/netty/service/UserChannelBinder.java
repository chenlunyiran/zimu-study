package com.zimu.study.netty.service;

import com.zimu.study.netty.annotation.ws.WSUnbindChannel;
import com.zimu.study.netty.annotation.ws.WsAPIOpMapping;
import com.zimu.study.netty.annotation.ws.WsOpService;
import com.zimu.study.netty.model.Result;
import com.zimu.study.netty.util.WsUtil;
import io.netty.channel.Channel;
import lombok.Getter;
import lombok.extern.slf4j.Slf4j;
import lombok.var;
import org.springframework.util.CollectionUtils;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

import static com.zimu.study.netty.constants.ChannelAttributes.USER_ID;

/**
 * @author xue
 * Created on 2019-01-15.
 * 登录（需要签名）
 */
@Slf4j
@WsOpService
public class UserChannelBinder {

    @Getter
    private static final Map<String, List<Channel>> channelMap = new ConcurrentHashMap<>();


    @WsAPIOpMapping("v1/login")
    public Result bindChannel(String userId, Channel channel) {
        channel.attr(USER_ID).set(userId);
        List<Channel> channels = channelMap.getOrDefault(userId, new ArrayList<>());
        channels.add(channel);
        channelMap.put(userId, channels);

        return Result.success("ok");
    }

    public boolean removeChannel(String userId, Channel channel) {
        channelMap.getOrDefault(userId, Collections.emptyList()).remove(channel);
        if (getChannelByUser(userId).size() == 0) {
            channelMap.remove(userId);
            return true;
        }

        return false;
    }

    @WSUnbindChannel
    public void unbindChannel(String userId) {
        channelMap.remove(userId);
    }

    public static List<Channel> getChannelByUser(String userId) {
        return channelMap.getOrDefault(userId, Collections.emptyList());
    }

    public static Long getBrokerIdByUserId(String userId) {
        var channels = channelMap.get(userId);
        if (CollectionUtils.isEmpty(channels)) {
            return null;
        }
        return WsUtil.getBrokerId(channels.get(0));
    }
}
