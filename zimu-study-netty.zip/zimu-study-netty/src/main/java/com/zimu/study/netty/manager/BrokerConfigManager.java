//package com.zimu.study.netty.manager;
//
//import com.fota.asset.domain.enums.AssetTypeEnum;
//import com.fota.open.option.domain.BrokerConfigDO;
//import com.fota.open.option.domain.UserBaseDO;
//import com.fota.open.option.domain.vo.OpenCapitalAssetsVO;
//import com.fota.open.option.mapper.OptionBrokerConfigMapper;
//import com.fota.open.option.mapper.OptionUserBaseMapper;
//import com.fota.option.common.AssetsBean;
//import com.fota.option.ds.BrokerOtherConfig;
//import com.fota.option.ds.ConfigCenter;
//import com.fota.option.enums.OptionRoleEnum;
//import com.zimu.study.netty.model.BrokerConfigDO;
//import lombok.extern.slf4j.Slf4j;
//import org.springframework.beans.factory.annotation.Autowired;
//import org.springframework.stereotype.Component;
//
//import java.util.ArrayList;
//import java.util.List;
//import java.util.Objects;
//import java.util.Optional;
//
///**
// * 券商相关配置信息
// * create on 15/01/2019
// *
// * @author JASON.TAO
// */
//@Component
//@Slf4j
//public class BrokerConfigManager {
//
//    @Autowired
//    private OptionBrokerConfigMapper optionBrokerConfigMapper;
//    @Autowired
//    private OptionUserBaseMapper optionUserBaseMapper;
//
//
//    public Integer addBrokerConfig(BrokerConfigDO brokerConfigDO) {
//        return optionBrokerConfigMapper.insert(brokerConfigDO);
//    }
//
//    public Integer updateBrokerConfig(BrokerConfigDO brokerConfigDO) {
//        return optionBrokerConfigMapper.update(brokerConfigDO);
//    }
//
//    public BrokerConfigDO getBrokerConfigByAPIKey(String apiKey) {
//        return optionBrokerConfigMapper.getByApiKey(apiKey);
//    }
//
//    public BrokerConfigDO getBrokerConfigDBById(Long id) {
//        return optionBrokerConfigMapper.getById(id);
//    }
//
//    /**
//     * 获取该用户的模拟账号是否需要重置按钮，默认为1
//     * @param userId
//     * @return
//     */
//    public Integer getSimAccountResetStatus(Long userId){
//        Optional<UserBaseDO> userBaseDOOptional = Optional.ofNullable(optionUserBaseMapper.getByUserId(userId));
//        if (userBaseDOOptional.isPresent()) {
//            BrokerOtherConfig brokerOtherConfig = getBrokerConfigById(userBaseDOOptional.get().getBrokerId());
//            return brokerOtherConfig.getSimAccountResetStatus();
//        }
//        return 1;
//    }
//
//    /**
//     * 根据brokerId获取该用户的资产list
//     * @param brokerId
//     * @return
//     */
//    public List<OpenCapitalAssetsVO> getCapitalAssetsByBrokerId(Long brokerId) {
//        List<OpenCapitalAssetsVO> list = new ArrayList<>();
//        BrokerOtherConfig brokerOtherConfig = getBrokerConfigById(brokerId);
//        brokerOtherConfig.getSupportCurrencyList().forEach(capitalAssetsBean -> {
//            list.add(new OpenCapitalAssetsVO(capitalAssetsBean));
//        });
//        return list;
//    }
//
//    /**
//     * asset信息是否在该券商下
//     * @param brokerId
//     * @param assetId
//     * @return true是存在
//     */
//    public boolean isExistAssetForBroker(Long brokerId, Integer assetId){
//        try {
//            List<OpenCapitalAssetsVO> capitalAssets = getCapitalAssetsByBrokerId(brokerId);
//            long count = capitalAssets.stream().filter(openCapitalAssetsVO -> (openCapitalAssetsVO.getId().equals(assetId))).count();
//            if (count != 0) {
//                return true;
//            }
//        } catch (Exception e) {
//            log.error("isExistAssetId error, brokerId:{}, assetId:{}", brokerId, assetId, e);
//        }
//        return false;
//    }
//    public boolean isExistAssetForBroker(Long brokerId, Integer assetId, String assetName){
//        try {
//            List<OpenCapitalAssetsVO> capitalAssets = getCapitalAssetsByBrokerId(brokerId);
//            long count = capitalAssets.stream().filter(openCapitalAssetsVO -> (openCapitalAssetsVO.getId().equals(assetId) && openCapitalAssetsVO.getName().equalsIgnoreCase(assetName))).count();
//            if (count != 0) {
//                return true;
//            }
//        } catch (Exception e) {
//            log.error("isExistAssetIdAndAssetName error, brokerId:{}, assetId:{}, assetName:{}", brokerId, assetId, assetName, e);
//        }
//        return false;
//    }
//
//    /**
//     * 从内存拿到配置信息
//     * @param brokerId
//     * @return
//     */
//    public BrokerOtherConfig getBrokerConfigById(Long brokerId) {
//        if (brokerId == null || brokerId <= 0) {
//            return ConfigCenter.getDefaultBrokerOtherConfig();
//        }
//        return ConfigCenter.getBrokerOtherConfig(brokerId);
//    }
//
//    /**
//     * 获取默认的配置信息
//     * @return
//     */
//    private BrokerOtherConfig getBrokerOtherConfigForDefault() {
//        BrokerOtherConfig brokerOtherConfig = new BrokerOtherConfig();
//
//        brokerOtherConfig.setSimAccountResetStatus(1);
//
//        List<AssetsBean> assetsBeans = new ArrayList<>();
//        assetsBeans.add(new AssetsBean(1, "BTC/USD"));
//        assetsBeans.add(new AssetsBean(2, "ETH/USD"));
//        brokerOtherConfig.setAssets(assetsBeans);
//
//        List<OptionRoleEnum> capitalAssets = new ArrayList<>();
//        capitalAssets.add(OptionRoleEnum.VFOTA);
//        brokerOtherConfig.setSupportCurrencyList(capitalAssets);
//
//        return brokerOtherConfig;
//    }
//
//    /**
//     * 该币种是否是有效币种
//     * @param currency
//     * @param brokerId
//     * @return
//     */
//    public Boolean isValidCurrency(Integer currency, Long brokerId) {
//        if (Objects.equals(currency, AssetTypeEnum.USDT.getCode())) {
//            currency = OptionRoleEnum.USDT.getId();
//        }
//        if (!OptionRoleEnum.validCurrency(currency)) {
//            return false;
//        }
//        Optional<List<OpenCapitalAssetsVO>> openCapitalAssetsVOS = Optional.ofNullable(getCapitalAssetsByBrokerId(brokerId));
//        if (!openCapitalAssetsVOS.isPresent()) {
//            return false;
//        } else {
//            Integer cur = currency;
//            long count = openCapitalAssetsVOS.get().stream().filter(capitalAssetsVO -> (capitalAssetsVO.getId().equals(cur))).count();
//            if (count == 0) {
//                return false;
//            }
//        }
//        return true;
//    }
//}
