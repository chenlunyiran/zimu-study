package com.zimu.study.netty.manager;

import com.alibaba.fastjson.JSON;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.redis.core.RedisTemplate;
import org.springframework.data.redis.core.ValueOperations;
import org.springframework.data.redis.core.ZSetOperations;
import org.springframework.stereotype.Component;
import org.springframework.util.CollectionUtils;

import java.time.Duration;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.TimeUnit;

/**
 * @Author: jiguang.qi
 * @date 2018/7/6
 */
@Slf4j
@Component
public class RedisManager {

	@Autowired
	private RedisTemplate<String, Object> redisTemplate;

	public void hset(String key, String hkey, Object value, Long time){
		redisTemplate.opsForHash().put(key, hkey, JSON.toJSONString(value));
		if(time > 0) {
			redisTemplate.expire(key, time, TimeUnit.SECONDS);
		}
	}

	public <T> T hget(String key, String hkey, Class<T> clazz) {
		Object object = redisTemplate.opsForHash().get(key, hkey);
		return object == null? null: clazz == String.class? (T) object.toString() : JSON.parseObject(object.toString(), clazz);
	}

	public void hmset(String key, Map<String, String> map, Long time) throws Exception {
		redisTemplate.opsForHash().putAll(key, map);
		if(time > 0) {
			redisTemplate.expire(key, time, TimeUnit.SECONDS);
		}
	}

	public void hmset(String key, Map<String, ? extends Object> map) {
		Map<String, String> saveMap = new HashMap<>(map.size());
		map.entrySet().forEach(entry -> saveMap.put(entry.getKey(), JSON.toJSONString(entry.getValue())));
		redisTemplate.opsForHash().putAll(key, saveMap);
	}

	public List<Object> hmGet(String key, List subKeys) {
		List list = redisTemplate.opsForHash().multiGet( key, subKeys);
		return list;
	}

	public boolean setnx(String key, Object value, Integer time) throws Exception{
		boolean result = redisTemplate.opsForValue().setIfAbsent(key, value);
		if(result) {
			redisTemplate.expire(key, time, TimeUnit.SECONDS);
		}
		return result;
	}

	public boolean expire(final String key, long expire) throws Exception{
		return redisTemplate.expire(key, expire, TimeUnit.SECONDS);
	}

	/**
	 * 普通缓存获取
	 *
	 * @param key 键
	 * @return 值
	 */
	public Object get(String key) {
		if (null == key){
			return null;
		}
		try {
			return redisTemplate.opsForValue().get(key);
		} catch (Exception e) {
			log.error("get({})", key, e);
		}
		return null;
	}

	/**
	 * 获取list缓存的内容
	 *
	 * @param key   键
	 * @param start 开始
	 * @param end   结束  0 到 -1代表所有值
	 * @return
	 */
	public List<Object> lGet(String key, long start, long end) {
		try {
			return redisTemplate.opsForList().range(key, start, end);
		} catch (Exception e) {
			log.error("lGet({}, {}, {})", key, start, end, e);
			return null;
		}
	}

	/**
	 * 删除缓存
	 *
	 * @param key 可以传一个值 或多个
	 */
	public void del(String... key) {
		try {
			if (key != null && key.length > 0) {
				if (key.length == 1) {
					redisTemplate.delete(key[0]);
				} else {
					redisTemplate.delete(CollectionUtils.arrayToList(key));
				}
			}
		} catch (Exception e) {
			log.error("del({})", key, e);
		}
	}

	public <K, V> Map<K, V> hgetall(String key) {

		return redisTemplate.<K, V>opsForHash().entries(key);
	}

	public void hputall(String key, Map<?, ?> map) {
		redisTemplate.opsForHash().putAll(key, map);
	}

	public <T> List<T> hgetall(String key, Class<T> clazz) throws Exception {
		List list = redisTemplate.opsForHash().values(key);
		List<T> list2= new ArrayList<>();
		if(!CollectionUtils.isEmpty(list)) {
			for(Object object: list) {
				list2.add(JSON.parseObject(object.toString(), clazz));
			}
		}
		return list2;
	}

	public boolean setWithExpire(final String key, final Object value, Duration expire) {
		try {
			ValueOperations<String, Object> vOps = redisTemplate.opsForValue();
			vOps.set(key, value, expire.getSeconds(), TimeUnit.SECONDS);
			return true;
		} catch (Exception e) {
			log.error("redis set error", e);
			return false;
		}
	}

	public Boolean zset(String key, String value, Double score){
		Boolean ret = false;
		try {
			ret = redisTemplate.opsForZSet().add(key, value, score);
		}catch (Exception e){
			log.error("redisTemplate.opsForZSet().add failed, key:{}, value:{}, score:{}", key, value, score);
		}
		return ret;
	}

	public Double zIncreament(String key, String value, Double score, TimeUnit unit, long timeout){
		Double ret = null;
		try {
			ret = redisTemplate.opsForZSet().incrementScore(key, value, score);
		}catch (Exception e){
			log.error("redisTemplate.opsForZSet().add failed, key:{}, value:{}, score:{}", key, value, score);
		}
		redisTemplate.expire(key, timeout, unit);
		return ret;
	}

	public Set<ZSetOperations.TypedTuple<Object>> zRevRangeWithScore(String key, long startRank, long endRank){
		startRank = startRank - 1L;
		endRank = endRank - 1L;
		Set<ZSetOperations.TypedTuple<Object>> set = new HashSet<>();
		try {
			set =  redisTemplate.opsForZSet().reverseRangeWithScores(key, startRank, endRank);
		}catch (Exception e){
			log.error("redisTemplate.opsForZSet().reverseRangeWithScores failed, key:{}", key, e);
		}
		return set;
	}

	public Long zRemove(String key, String member){
		Long ret = 0L;
		try {
			ret =  redisTemplate.opsForZSet().remove(key, member);
		}catch (Exception e){
			log.error("redisTemplate.opsForZSet().removefailed, key:{}", key, e);
		}
		return ret;
	}
}
