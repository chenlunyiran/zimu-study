package com.zimu.study.netty.vo;

/**
 * @author xue
 * Created on 2019-02-14.
 */
public interface WSRequestArgs {
}
