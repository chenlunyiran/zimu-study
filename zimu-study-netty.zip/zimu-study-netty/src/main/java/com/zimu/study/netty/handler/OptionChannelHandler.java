package com.zimu.study.netty.handler;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.fota.open.option.constant.GlobalConstant;
import com.fota.open.option.domain.enums.UrlRelationReqType;
import com.fota.open.option.service.UserChannelBinder;
import com.fota.open.option.vo.WSResponseVO;
import com.fota.option.common.Result;
import com.fota.option.common.WsResult;
import com.fota.option.common.utils.BeanUtil;
import com.fota.option.common.utils.TokenUtil;
import com.fota.option.manager.SessionManager;
import com.fota.option.websocket.MessageHandlerFactory;
import com.fota.option.websocket.entity.ChannelModule;
import com.fota.option.websocket.entity.enums.ModuleEnum;
import com.fota.option.websocket.utils.Attributes;
import com.fota.option.websocket.utils.GlobalUserUtil;
import com.fota.option.websocket.utils.WsUtil;
import com.zimu.study.netty.constants.GlobalConstant;
import com.zimu.study.netty.enums.ModuleEnum;
import com.zimu.study.netty.enums.UrlRelationReqType;
import com.zimu.study.netty.manager.SessionManager;
import com.zimu.study.netty.model.ChannelModule;
import com.zimu.study.netty.model.Result;
import com.zimu.study.netty.model.WsResult;
import com.zimu.study.netty.service.MessageHandlerFactory;
import com.zimu.study.netty.service.UserChannelBinder;
import com.zimu.study.netty.util.Attributes;
import com.zimu.study.netty.util.BeanUtil;
import com.zimu.study.netty.util.GlobalUserUtil;
import com.zimu.study.netty.util.TokenUtil;
import com.zimu.study.netty.util.WsUtil;
import com.zimu.study.netty.vo.WSResponseVO;
import io.netty.buffer.ByteBuf;
import io.netty.buffer.Unpooled;
import io.netty.channel.Channel;
import io.netty.channel.ChannelFuture;
import io.netty.channel.ChannelFutureListener;
import io.netty.channel.ChannelHandlerContext;
import io.netty.channel.SimpleChannelInboundHandler;
import io.netty.handler.codec.http.DefaultFullHttpResponse;
import io.netty.handler.codec.http.FullHttpRequest;
import io.netty.handler.codec.http.HttpHeaders;
import io.netty.handler.codec.http.HttpResponseStatus;
import io.netty.handler.codec.http.websocketx.CloseWebSocketFrame;
import io.netty.handler.codec.http.websocketx.PingWebSocketFrame;
import io.netty.handler.codec.http.websocketx.PongWebSocketFrame;
import io.netty.handler.codec.http.websocketx.TextWebSocketFrame;
import io.netty.handler.codec.http.websocketx.WebSocketFrame;
import io.netty.handler.codec.http.websocketx.WebSocketServerHandshaker;
import io.netty.handler.codec.http.websocketx.WebSocketServerHandshakerFactory;
import io.netty.handler.timeout.IdleStateEvent;
import io.netty.util.CharsetUtil;
import io.netty.util.ReferenceCountUtil;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.util.CollectionUtils;

import javax.websocket.MessageHandler;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.concurrent.ConcurrentHashMap;

/**
 * @author James Shen
 * @since 2018/10/7
 */
public class OptionChannelHandler extends SimpleChannelInboundHandler<Object> {

    private static final Logger log = LoggerFactory.getLogger("webSocket");

    private static final String WEBSOCKET_URI = "wsoption";
    private static final String WEBSOCKET = "websocket";
    private static final String UPGRADE = "Upgrade";
    private static final String PING = "ping";
    private static final String PONG = "pong";


    private SessionManager sessionManager = BeanUtil.getBean(SessionManager.class);
    private TokenUtil tokenUtil = BeanUtil.getBean(TokenUtil.class);

    private WebSocketServerHandshaker handShaker;

    /**
     * 首次进来，保存channel就好
     * @param ctx
     * @param msg
     * @throws Exception
     */
    @Override
    protected void channelRead0(ChannelHandlerContext ctx, Object msg) throws Exception {
        if (msg instanceof FullHttpRequest) {
            handlerHttpRequest(ctx,(FullHttpRequest) msg);
        } else if (msg instanceof WebSocketFrame) {
            handlerWebSocketFrame(ctx,(WebSocketFrame) msg);
        } else {
            throw new RuntimeException("Requests that cannot be processed");
        }
    }

    /**
     * 处理http请求，最开始进来是一个http请求
     * @param ctx
     * @param request
     */
    private void handlerHttpRequest(ChannelHandlerContext ctx, FullHttpRequest request) {
        if(!request.getDecoderResult().isSuccess() || (!WEBSOCKET.equalsIgnoreCase(request.headers().get(UPGRADE)))){
            log.error("ws>> webSocket doHandlerHttpRequest failed");
            sendHttpResponse(ctx, request,new DefaultFullHttpResponse(HttpVersion.HTTP_1_1, HttpResponseStatus.BAD_REQUEST));
        }
        //可以通过url获取其他参数
        WebSocketServerHandshakerFactory factory = new WebSocketServerHandshakerFactory(
                "ws://" + request.headers().get("Host") + "/" + WEBSOCKET_URI + "",null,false
        );
        // 构造握手响应返回
        handShaker = factory.newHandshaker(request);
        if(handShaker == null){
            WebSocketServerHandshakerFactory.sendUnsupportedWebSocketVersionResponse(ctx.channel());
        }
        WsUtil.saveBrokerId(ctx, request, GlobalConstant.DEFAULT_FOTA_BROKER_ID+"");
        handShaker.handshake(ctx.channel(), request);
    }

    private static void sendHttpResponse(ChannelHandlerContext ctx, FullHttpRequest req, DefaultFullHttpResponse res) {
        // 返回应答给客户端
        if (res.getStatus().code() != 200) {
            ByteBuf buf = Unpooled.copiedBuffer(res.getStatus().toString(), CharsetUtil.UTF_8);
            res.content().writeBytes(buf);
            buf.release();
        }

        // 如果是非Keep-Alive，关闭连接
        ChannelFuture f = ctx.channel().writeAndFlush(res);
        if (!HttpHeaders.isKeepAlive(req) || res.getStatus().code() != 200) {
            f.addListener(ChannelFutureListener.CLOSE);
            log.error("ws>> webSocket close ");
        }
    }

    /**
     * 处理webSocket消息
     * @param ctx
     * @param frame
     */
    private void handlerWebSocketFrame(ChannelHandlerContext ctx, WebSocketFrame frame) {
        if (frame instanceof CloseWebSocketFrame) {
            log.info("ws>> 【webSocket close】");
            // netty的问题，frame 在使用的时候需要引用+1
            ReferenceCountUtil.retain(frame);
            handShaker.close(ctx.channel(), (CloseWebSocketFrame) frame.retain());
            return;
        }
        if (frame instanceof PingWebSocketFrame) {
            return;
        }
        if (frame instanceof PongWebSocketFrame) {
            return;
        }
        if (!(frame instanceof TextWebSocketFrame)) {
            log.info("ws>> 【No binary support]");
            throw new UnsupportedOperationException(String.format("%s frame types not supported", frame.getClass().getName()));
        }
        String msg = ((TextWebSocketFrame) frame).text();
        ChannelModule channelModule = null;
        try {
            channelModule = JSON.parseObject(msg, ChannelModule.class);
        } catch (Exception e) {
            log.error("ws >> json parse object error", e);
            return;
        }
        String event = channelModule.getEvent();
        if (StringUtils.isNotEmpty(event)
                && StringUtils.equalsIgnoreCase(PING, event)) {
            JSONObject jsonObject = new JSONObject();
            jsonObject.put("event", PONG);
            sendMessageToOne(jsonObject.toJSONString(), ctx.channel());
            return;
        }
        log.info("ws >> receive message: {}", msg);
        // 绑定 user/session - channel订阅关系
        bindChannel(channelModule, ctx);
        Map<Integer, ChannelModule> channelModuleMap = GlobalUserUtil.getChannelMap().get(ctx.channel());
        if (channelModuleMap != null) {
            channelModuleMap.put(channelModule.getReqType(), channelModule);
        }
        // 直接响应
        Integer reqType = channelModule.getReqType();

        MessageHandler messageHandler = MessageHandlerFactory.createMessageHandler(ModuleEnum.getEnumByCode(reqType));
        if (Objects.nonNull(messageHandler)) {
            messageHandler.push(ctx.channel(), channelModule);
            return;
        }

    }

    /**
     * 连接上服务器  开始处理事件
     * @param ctx
     * @throws Exception
     */
    @Override
    public void handlerAdded(ChannelHandlerContext ctx) throws Exception {
        log.info("ws>>【handlerAdded】====> {}, connect number: {}",
                ctx.channel().id(), GlobalUserUtil.getChannelNumber());

        GlobalUserUtil.handlerAdded(ctx.channel());
    }

    /**
     * 断开连接
     * @param ctx
     * @throws Exception
     */
    @Override
    public void handlerRemoved(ChannelHandlerContext ctx) throws Exception {
        log.info("ws>>【handlerRemoved】====> {}, connect number: {}",
                ctx.channel().id(), GlobalUserUtil.getChannelNumber());
        GlobalUserUtil.handlerRemoved(ctx.channel());
    }

    /**
     * 连接异常   需要关闭相关资源
     * @param ctx
     * @param cause
     * @throws Exception
     */
    @Override
    public void exceptionCaught(ChannelHandlerContext ctx, Throwable cause) throws Exception {
        GlobalUserUtil.handlerRemoved(ctx.channel());
        ctx.close();
        ctx.channel().close();
        log.info("ws>> 【exceptionCaught】=====>: {}, connect number: {}",
                ctx.channel(), GlobalUserUtil.getChannelNumber());
    }

    /**
     * 活跃的通道  也可以当作用户连接上客户端进行使用
     * @param ctx
     * @throws Exception
     */
    @Override
    public void channelActive(ChannelHandlerContext ctx) throws Exception {
        log.info("ws>>【channelActive】=====>: {}, connect number: {}",
                ctx.channel(), GlobalUserUtil.getChannelNumber());
    }

    /**
     * 不活跃的通道  就说明用户失去连接
     * @param ctx
     * @throws Exception
     */
    @Override
    public void channelInactive(ChannelHandlerContext ctx) throws Exception {
        log.info("ws>>【channelInactive】=====> {}, connect number: {}",
                ctx.channel(), GlobalUserUtil.getChannelNumber());
    }

    /**
     * 这里只要完成 flush
     * @param ctx
     * @throws Exception
     */
    @Override
    public void channelReadComplete(ChannelHandlerContext ctx) throws Exception {
        ctx.flush();
    }

    /**
     * 这里是保持服务器与客户端长连接  进行心跳检测 避免连接断开
     * @param ctx
     * @param evt
     * @throws Exception
     */
    @Override
    public void userEventTriggered(ChannelHandlerContext ctx, Object evt) throws Exception {
        if (evt instanceof IdleStateEvent) {
            IdleStateEvent stateEvent = (IdleStateEvent) evt;
            PingWebSocketFrame ping = new PingWebSocketFrame();
            switch (stateEvent.state()) {
                case READER_IDLE:
                    ctx.writeAndFlush(ping);
                    break;
                case WRITER_IDLE:
                    ctx.writeAndFlush(ping);
                    break;
                case ALL_IDLE:
                    break;
                default:
                    break;
            }
        }
    }

    /**
     * webSocket消息推送
     * @param msg
     * @param channel
     */
    public static void sendMessageToOne(String msg, Channel channel) {
        channel.writeAndFlush(new TextWebSocketFrame(msg));
    }

    /**
     * webSocket消息推送(针对用户)
     * @param msg
     * @param userId
     */
    public static void sendMessageToUser(String msg, Long userId) {
        Map<Long, List<Channel>> userChannelMap = GlobalUserUtil.getUserSessionChannelMap();
        if (userChannelMap.containsKey(userId)) {
            List<Channel> channelList = userChannelMap.get(userId);
            synchronized (channelList) {
                if (!CollectionUtils.isEmpty(channelList)) {
                    channelList.removeIf(channel -> StringUtils.isEmpty(WsUtil.getSessionId(channel)));
                }
            }
            channelList.forEach(channel -> sendMessageToOne(msg, channel));
        }
    }

    /**
     * 推送消息到sdk和主站方式
     */
    public static void sendMessageToAllChannelUser(UrlRelationReqType url, String ops, WsResult result, Long userId) {
        sendMessageToUser(JSON.toJSONString(result), userId);
        sendMessageToOpenUser(url, ops, result, userId);
    }

    public static void sendMessageToOpenUser(UrlRelationReqType url, String ops, Result result, Long userId) {
        WSResponseVO wsResponseVO = new WSResponseVO();
        wsResponseVO.setCode(result.getCode());
        wsResponseVO.setMsg(result.getMsg());
        wsResponseVO.setData(result.getData());
        wsResponseVO.setUrl(url.getUrl());
        wsResponseVO.setOp(ops);
        String string = JSONObject.toJSONString(wsResponseVO);
        for (Channel channel : UserChannelBinder.getChannelMap().getOrDefault(userId.toString(), Collections.emptyList())) {
            sendMessageToOne(string, channel);
        }
    }

    /**
     * TODO 当前只能有一个session生效？
     * 绑定 user/session - channel订阅关系
     * @param channelModule
     * @param ctx
     */
    private void bindChannel(ChannelModule channelModule, ChannelHandlerContext ctx) {
        String sessionId = channelModule.getSessionId();
        Integer platformType = channelModule.getPlatformType();
        if (StringUtils.isNotEmpty(sessionId)) {
            // 绑定 sessionId -> channel
            ctx.channel().attr(Attributes.SESSION).set(sessionId);
            ctx.channel().attr(Attributes.PLATFORM_TYPE).set(platformType);
            Long userId;
            if (platformType!=null && 2==platformType.intValue()) {
                userId = tokenUtil.getUserIdByLoginToken(sessionId);
            } else {
                userId = sessionManager.getUserId(sessionId);
            }
            if (userId != null) {
                // 绑定 userId -> channel
                ctx.channel().attr(Attributes.USER).set(userId);
                ConcurrentHashMap<Long, List<Channel>> userChannelMap = GlobalUserUtil.getUserSessionChannelMap();
                if (userChannelMap.containsKey(userId)) {
                    List<Channel> channelList = userChannelMap.get(userId);
                    if (!channelList.contains(ctx.channel())) {
                        channelList.add(ctx.channel());
                    }
                } else {
                    List<Channel> channelList = new ArrayList<>();
                    channelList.add(ctx.channel());
                    userChannelMap.put(userId, channelList);
                }
            }
        }
    }
}
