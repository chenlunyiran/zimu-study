package com.zimu.study.netty.manager;

import com.fota.open.option.domain.BrokerConfigDO;
import lombok.Getter;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.util.Base64;
import java.util.Map;
import java.util.Optional;
import java.util.concurrent.ConcurrentHashMap;

/**
 * create on 15/01/2019
 *
 * @author JASON.TAO
 */
@Component
@Slf4j
public class BrokerCacheManager {
    private BrokerConfigManager brokerConfigManager;
    private final Map<String, CachedDigest> cache = new ConcurrentHashMap<>();

    public String signByCachedDigest(String apikey, String digest) throws Exception {
        CachedDigest cachedDigest;
        if (cache.containsKey(apikey)) {
             cachedDigest = cache.get(apikey);
        } else {
            cachedDigest = queryAndCache(apikey);
        }
        if (cachedDigest == null) {
            throw new Exception("can not process");
        }
        MessageDigest md = cachedDigest.getMessageDigest();
        return Base64.getEncoder().encodeToString(md.digest(digest.getBytes()));
    }

    private CachedDigest queryAndCache(String apikey) {
        Optional<BrokerConfigDO> configDOOptional = Optional.ofNullable(brokerConfigManager.getBrokerConfigByAPIKey(apikey));
        if (configDOOptional.isPresent()) {
            BrokerConfigDO configDO = configDOOptional.get();
            try {
                MessageDigest md = MessageDigest.getInstance("SHA-256");
                md.update(configDO.getAppSecret().getBytes());
                CachedDigest cachedDigest = new CachedDigest(apikey, configDO.getAppSecret(), md, configDO.getBrokerId());
                cache.put(apikey, cachedDigest);
                return cachedDigest;
            } catch (NoSuchAlgorithmException e) {
                log.error("MessageDigest error", e);
            }
        }
        return null;
    }

    public Long getBrokerId(String apikey) {
        if (StringUtils.isEmpty(apikey)) {
            return null;
        }
        CachedDigest cachedDigest;
        if (cache.containsKey(apikey)) {
            cachedDigest = cache.get(apikey);
        } else {
            cachedDigest = queryAndCache(apikey);
        }
        if (cachedDigest == null) {
            log.error("getBrokerId({}) error!cache:{}", apikey, cache);
            return null;
        }
        return cachedDigest.getBrokerId();
    }

    public String getSecret(String apiKey) {
        CachedDigest cachedDigest;
        if (cache.containsKey(apiKey)) {
            cachedDigest = cache.get(apiKey);
        } else {
            cachedDigest = queryAndCache(apiKey);
        }
        if (cachedDigest == null) {
            return "";
        }
        return cachedDigest.getApiSecret();
    }


    protected class CachedDigest{
        @Getter
        private String apiKey;
        @Getter
        private String apiSecret;
        @Getter
        private Long brokerId;
        @Getter
        private MessageDigest messageDigest;
        public CachedDigest() {}

        public CachedDigest(String apiKey, String apiSecret, MessageDigest messageDigest, Long brokerId) {
            this.apiKey = apiKey;
            this.apiSecret = apiSecret;
            this.messageDigest = messageDigest;
            this.brokerId = brokerId;
        }
    }

    @Autowired
    public void setBrokerConfigManager(BrokerConfigManager brokerConfigManager) {
        this.brokerConfigManager = brokerConfigManager;
    }
}
