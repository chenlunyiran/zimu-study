package com.zimu.study.netty.constants;

/**
 * @author xue
 * Created on 2019-01-15.
 */
public final class WSOps {

    public static final String UNSUBSCRIBE = "unsubscribe";

    public static final String SUBSCRIBE = "subscribe";

    public static final String API = "api";
}
