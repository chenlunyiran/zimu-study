package com.zimu.study.netty.service;

import com.zimu.study.netty.enums.PlatformEnum;
import com.zimu.study.netty.manager.BrokerCacheManager;
import com.zimu.study.netty.manager.UserBaseOpenManager;
import com.zimu.study.netty.util.SignUtil;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.codec.binary.Base64;
import org.apache.commons.codec.digest.DigestUtils;
import org.apache.commons.codec.digest.HmacAlgorithms;
import org.apache.commons.codec.digest.HmacUtils;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.nio.charset.StandardCharsets;
import java.util.Objects;
import java.util.UUID;

/**
 * Created on 2019-01-15.
 */
@Slf4j
@Service
public class ApiSecurityService {

//    private BrokerConfigManager brokerConfigManager;

    private BrokerCacheManager brokerCacheManager;

    private UserBaseOpenManager userBaseOpenManager;

    public String generateKey() {
        return UUID.randomUUID().toString();
    }

    public String generateSecret(String userId) {
        return DigestUtils.sha1Hex(userId + System.currentTimeMillis());
    }

    public String getSecretByKey(String apiKey) {
        return brokerCacheManager.getSecret(apiKey);
    }

    public boolean validateKeyAndSecret() {

        return false;
    }

    public boolean validateKey(String apiKey) {
        try {
            return Objects.nonNull(brokerCacheManager.getBrokerId(apiKey));
        } catch (Exception e) {
            log.error("validateKey({})", apiKey, e);
            return false;
        }
    }

    public String getTokenByUserId(String userId) {
        if (StringUtils.isEmpty(userId)) {
            return "";
        }
        return userBaseOpenManager.getTokenByUserId(Long.parseLong(userId));
    }

//    public BrokerConfigDO getBrokerByAPIKey(String key) {
//        return brokerConfigManager.getBrokerConfigByAPIKey(key);
//    }

    public boolean validateSignature(String stringForSigning, String secret, String signFromRequest, String platform, String requestURL) {

        if (StringUtils.isEmpty(stringForSigning) || StringUtils.isEmpty(secret) || StringUtils.isEmpty(signFromRequest)) {
            return false;
        }
        // 如果是pc的话，走另外一套验证方式
        String calculatedSign;
        if (PlatformEnum.PC.getType().equals(platform)) {
            String secretMd5 = SignUtil.getMD5(secret);
            String calculated = stringForSigning+secretMd5;
            calculatedSign = SignUtil.getMD5(calculated);
        } else {
            calculatedSign = Base64.encodeBase64String(
                    new HmacUtils(HmacAlgorithms.HMAC_SHA_256, secret)
                            .hmacHex(Base64.encodeBase64String(stringForSigning.getBytes(StandardCharsets.UTF_8)))
                            .getBytes()
            );
        }
        Boolean is = StringUtils.equalsIgnoreCase(signFromRequest, calculatedSign);
        if (!is) {
            log.error("【validateSignature error】requestURL:{}, stringForSigning:{}, secret:{}, platform:{}, signFromBroker:{}, signFromFota:{}",
                    requestURL, stringForSigning, secret, platform, signFromRequest, calculatedSign);
        }
        log.info("【validateSignature success】requestURL:{}, stringForSigning:{}, secret:{}, platform:{}, signFromBroker:{}, signFromFota:{}",
                requestURL, stringForSigning, secret, platform, signFromRequest, calculatedSign);
        return is;
    }

//    @Autowired
//    public void setBrokerConfigManager(BrokerConfigManager brokerConfigManager) {
//        this.brokerConfigManager = brokerConfigManager;
//    }
//
//    @Autowired
//    public void setBrokerCacheManager(BrokerCacheManager brokerCacheManager) {
//        this.brokerCacheManager = brokerCacheManager;
//    }

    @Autowired
    public void setUserBaseOpenManager(UserBaseOpenManager userBaseOpenManager) {
        this.userBaseOpenManager = userBaseOpenManager;
    }
}
