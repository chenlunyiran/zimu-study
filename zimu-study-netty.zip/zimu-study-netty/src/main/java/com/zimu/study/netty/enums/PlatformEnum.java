package com.zimu.study.netty.enums;

import lombok.Getter;

/**
 * @Author huangtao 2019/2/22 10:07 AM
 * @Description
 */
public enum  PlatformEnum {
    PC("1"),

    APP("2"),
            ;
    @Getter
    private String type;

    PlatformEnum(String type) {
        this.type = type;
    }
}
